export interface myinterface
{
    id:number,
    title:string,
    year:number,
    author:string
}